from .base import *

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}
DINGTALK_WEB_HOOK = "https://oapi.dingtalk.com/robot/send?access_token=15ed40817386f8ba6a90120519cad5e9a10fbc1ea789523e475107a7f12f02df"
DEBUG = True

ALLOWED_HOSTS = ['localhost']

