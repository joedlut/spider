import logging

import time

logger = logging.getLogger(__name__)

# 参数固定写 get_response
def performance_logger_middleware(get_response):
    def middle(request):
        start_time = time.time()

        # 处理完请求
        response = get_response(request)
        duration = time.time() - start_time
        response["X-Page-Duration-ms"] = int(duration * 1000)
        logging.info("%s %s %s",duration*1000,request.path,request.GET.dict())
        return response
    # 返回的是中间件函数名
    return middle

